"""Shared helpers: database, settings, categories, login decorators."""
import os
import re
import secrets
import sqlite3
import time
from functools import wraps

from flask import abort, flash, g, redirect, request, session, url_for

BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE, "karigar.db")
UPLOADS = os.path.join(BASE, "static", "uploads")
os.makedirs(UPLOADS, exist_ok=True)

GROUPS = {"worker": ("कारीगर", "Workers & Home Services"), "engineer": ("इंजीनियर", "Engineers"), "medical": ("डॉक्टर और मेडिकल सेवाएँ", "Doctors & Medical"), "equipment": ("मशीन और उपकरण", "Machines & Equipment")}

# booking status -> (hindi, english, css class)
STATUS = {
    "awaiting_payment": ("पेमेंट बाकी", "Payment pending", "wait"),
    "verifying": ("पेमेंट जाँच में", "Checking payment", "wait"),
    "held": ("पेमेंट सुरक्षित, काम चालू", "Paid - work in progress", "ok"),
    "done": ("काम पूरा", "Work done", "ok"),
    "released": ("कारीगर को पैसा मिल गया", "Worker paid", "ok"),
    "refunded": ("पैसा वापस हुआ", "Refunded", "bad"),
    "cancelled": ("रद्द", "Cancelled", "bad"),
}

DEFAULT_CATEGORIES = [
    ("carpenter", "बढ़ई", "Carpenter", "🪚", "worker"),
    ("plumber", "प्लंबर", "Plumber", "🚰", "worker"),
    ("electrician", "इलेक्ट्रीशियन", "Electrician", "💡", "worker"),
    ("mechanic", "मैकेनिक", "Mechanic", "🔧", "worker"),
    ("mason", "राजमिस्त्री", "Mason", "🧱", "worker"),
    ("painter", "पेंटर", "Painter", "🎨", "worker"),
    ("welder", "वेल्डर", "Welder", "🔥", "worker"),
    ("tiles", "टाइल्स मिस्त्री", "Tile worker", "◼️", "worker"),
    ("ac-fridge", "AC / फ्रिज मरम्मत", "AC & Fridge repair", "❄️", "worker"),
    ("driver", "ड्राइवर", "Driver", "🚚", "worker"),
    ("gardener", "माली", "Gardener", "🌿", "worker"),
    ("cleaner", "सफाई कर्मी", "Cleaner", "🧹", "worker"),
    ("barber", "नाई / बार्बर", "Barber & Grooming", "💈", "worker"),
    ("tailor", "दर्जी", "Tailor", "🧵", "worker"),
    ("labour", "मजदूर", "Labour", "💪", "worker"),
    ("civil-eng", "सिविल इंजीनियर", "Civil Engineer", "🏗️", "engineer"),
    ("electrical-eng", "इलेक्ट्रिकल इंजीनियर", "Electrical Engineer", "⚡", "engineer"),
    ("mechanical-eng", "मैकेनिकल इंजीनियर", "Mechanical Engineer", "⚙️", "engineer"),
    ("computer-eng", "कंप्यूटर इंजीनियर", "Computer Engineer", "💻", "engineer"),
    ("electronics-eng", "इलेक्ट्रॉनिक्स इंजीनियर", "Electronics Engineer", "📟", "engineer"),
    ("chemical-eng", "केमिकल इंजीनियर", "Chemical Engineer", "🧪", "engineer"),
    ("doctor", "डॉक्टर", "Doctor", "🩺", "medical"),
    ("dentist", "दंत चिकित्सक", "Dentist", "🦷", "medical"),
    ("nurse", "नर्स", "Nurse", "🩹", "medical"),
    ("physiotherapist", "फिजियोथेरेपिस्ट", "Physiotherapist", "🧘", "medical"),
    ("lab-technician", "लैब टेक्नीशियन", "Lab Technician", "🧪", "medical"),
    ("ambulance", "एम्बुलेंस सेवा", "Ambulance Service", "🚑", "medical"),
    ("jcb", "JCB / एक्सकेवेटर", "JCB / Excavator", "🚜", "equipment"),
    ("crane", "क्रेन सेवा", "Crane Service", "🏗️", "equipment"),
    ("tractor", "ट्रैक्टर किराया", "Tractor Rental", "🚜", "equipment"),
    ("concrete-mixer", "कंक्रीट मिक्सर", "Concrete Mixer", "🏗️", "equipment"),
    ("generator", "जनरेटर किराया", "Generator Rental", "🔌", "equipment"),
    ("welding-machine", "वेल्डिंग मशीन", "Welding Machine", "⚙️", "equipment"),
    ("scaffolding", "मचान / शटरिंग", "Scaffolding & Shuttering", "🧱", "equipment"),
    ("water-tanker", "पानी टैंकर", "Water Tanker", "🚛", "equipment"),
]

DEFAULT_SETTINGS = {"commission_pct": "10", "site_upi": "", "site_upi_name": "Karigar Saathi"}

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  phone TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN ('worker','customer')),
  city TEXT NOT NULL DEFAULT '',
  is_admin INTEGER NOT NULL DEFAULT 0,
  is_blocked INTEGER NOT NULL DEFAULT 0,
  upi_id TEXT NOT NULL DEFAULT '',
  created TEXT NOT NULL DEFAULT (date('now')));
CREATE TABLE IF NOT EXISTS profiles(
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  category TEXT NOT NULL,
  experience INTEGER NOT NULL DEFAULT 0,
  rate TEXT NOT NULL DEFAULT '',
  about TEXT NOT NULL DEFAULT '',
  photo TEXT NOT NULL DEFAULT '');
CREATE TABLE IF NOT EXISTS jobs(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  category TEXT NOT NULL,
  city TEXT NOT NULL,
  description TEXT NOT NULL,
  phone TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open',
  created TEXT NOT NULL DEFAULT (date('now')));
CREATE TABLE IF NOT EXISTS messages(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  sender_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  receiver_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  body TEXT NOT NULL,
  is_read INTEGER NOT NULL DEFAULT 0,
  created TEXT NOT NULL DEFAULT (datetime('now')));
CREATE TABLE IF NOT EXISTS reviews(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  worker_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  customer_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  stars INTEGER NOT NULL CHECK(stars BETWEEN 1 AND 5),
  comment TEXT NOT NULL DEFAULT '',
  created TEXT NOT NULL DEFAULT (date('now')),
  UNIQUE(worker_id, customer_id));
CREATE TABLE IF NOT EXISTS categories(
  slug TEXT PRIMARY KEY,
  hi TEXT NOT NULL, en TEXT NOT NULL, icon TEXT NOT NULL DEFAULT '🛠️',
  grp TEXT NOT NULL CHECK(grp IN ('worker','engineer','medical','equipment')),
  active INTEGER NOT NULL DEFAULT 1,
  sort INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS bookings(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER NOT NULL REFERENCES users(id),
  worker_id INTEGER NOT NULL REFERENCES users(id),
  description TEXT NOT NULL,
  amount INTEGER NOT NULL CHECK(amount > 0),
  commission_pct INTEGER NOT NULL,
  commission INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'awaiting_payment',
  utr TEXT NOT NULL DEFAULT '',
  payout_ref TEXT NOT NULL DEFAULT '',
  razorpay_order_id TEXT NOT NULL DEFAULT '',
  razorpay_payment_id TEXT NOT NULL DEFAULT '',
  payment_method TEXT NOT NULL DEFAULT 'upi',
  note TEXT NOT NULL DEFAULT '',
  created TEXT NOT NULL DEFAULT (datetime('now')),
  updated TEXT NOT NULL DEFAULT (datetime('now')));
CREATE UNIQUE INDEX IF NOT EXISTS bookings_utr ON bookings(utr) WHERE utr != '';
CREATE TABLE IF NOT EXISTS audit(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  admin_id INTEGER, action TEXT NOT NULL, detail TEXT NOT NULL DEFAULT '',
  created TEXT NOT NULL DEFAULT (datetime('now')));
"""


def init_db():
    con = sqlite3.connect(DB)
    con.executescript(SCHEMA)
    # upgrade existing databases safely
    booking_cols = {r[1] for r in con.execute("PRAGMA table_info(bookings)")}
    for col, ddl in (("razorpay_order_id", "TEXT NOT NULL DEFAULT ''"),
                     ("razorpay_payment_id", "TEXT NOT NULL DEFAULT ''"),
                     ("payment_method", "TEXT NOT NULL DEFAULT 'upi'")):
        if col not in booking_cols:
            con.execute(f"ALTER TABLE bookings ADD COLUMN {col} {ddl}")
    con.execute("CREATE UNIQUE INDEX IF NOT EXISTS bookings_razorpay_order ON bookings(razorpay_order_id) WHERE razorpay_order_id != ''")
    con.execute("CREATE UNIQUE INDEX IF NOT EXISTS bookings_razorpay_payment ON bookings(razorpay_payment_id) WHERE razorpay_payment_id != ''")
    # upgrade a database made by the first version of the site
    have = {r[1] for r in con.execute("PRAGMA table_info(users)")}
    for col, ddl in (("is_admin", "INTEGER NOT NULL DEFAULT 0"),
                     ("is_blocked", "INTEGER NOT NULL DEFAULT 0"),
                     ("upi_id", "TEXT NOT NULL DEFAULT ''")):
        if col not in have:
            con.execute(f"ALTER TABLE users ADD COLUMN {col} {ddl}")
    # Expand category group constraint for medical and equipment sections on old databases.
    cat_sql = con.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='categories'").fetchone()
    if cat_sql and "'medical'" not in (cat_sql[0] or ""):
        con.execute("ALTER TABLE categories RENAME TO categories_legacy")
        con.execute("""CREATE TABLE categories(
          slug TEXT PRIMARY KEY, hi TEXT NOT NULL, en TEXT NOT NULL, icon TEXT NOT NULL DEFAULT '🛠️',
          grp TEXT NOT NULL CHECK(grp IN ('worker','engineer','medical','equipment')),
          active INTEGER NOT NULL DEFAULT 1, sort INTEGER NOT NULL DEFAULT 0)""")
        con.execute("INSERT INTO categories(slug,hi,en,icon,grp,active,sort) SELECT slug,hi,en,icon,grp,active,sort FROM categories_legacy")
        con.execute("DROP TABLE categories_legacy")
    existing = {r[0] for r in con.execute("SELECT slug FROM categories")}
    con.executemany("INSERT INTO categories(slug,hi,en,icon,grp,sort) VALUES(?,?,?,?,?,?)",
                    [(*c, i) for i, c in enumerate(DEFAULT_CATEGORIES) if c[0] not in existing])
    for k, v in DEFAULT_SETTINGS.items():
        con.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)", (k, v))
    con.commit()
    con.close()


def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys=ON")
    return g.db


def close_db(_=None):
    d = g.pop("db", None)
    if d is not None:
        d.close()


def q(sql, args=(), one=False):
    cur = db().execute(sql, args)
    rows = cur.fetchall()
    cur.close()
    if one:
        return rows[0] if rows else None
    return rows


def run(sql, args=()):
    """Run a write and return the new row id."""
    cur = db().execute(sql, args)
    db().commit()
    return cur.lastrowid


def change(sql, args=()):
    """Run a write and return how many rows it changed (0 = nothing matched)."""
    cur = db().execute(sql, args)
    db().commit()
    return cur.rowcount


def setting(key):
    r = q("SELECT value FROM settings WHERE key=?", (key,), one=True)
    return r["value"] if r else DEFAULT_SETTINGS.get(key, "")


def set_setting(key, value):
    run("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (key, value))


def audit(action, detail=""):
    run("INSERT INTO audit(admin_id, action, detail) VALUES(?,?,?)",
        (g.user["id"] if g.get("user") else None, action, detail[:300]))


def load_cats():
    rows = q("SELECT * FROM categories ORDER BY sort, rowid")
    allc = [dict(slug=r["slug"], hi=r["hi"], en=r["en"], icon=r["icon"], group=r["grp"],
                 active=r["active"]) for r in rows]
    g.CAT = {c["slug"]: c for c in allc}           # every category, for showing old data
    g.CATS = [c for c in allc if c["active"]]      # only the ones people can pick now
    g.ACTIVE = {c["slug"] for c in g.CATS}


# ------------------------------------------------------------------- helpers
def clean_phone(s):
    d = re.sub(r"\D", "", s or "")
    if len(d) == 12 and d.startswith("91"):
        d = d[2:]
    if len(d) == 11 and d.startswith("0"):
        d = d[1:]
    return d if re.fullmatch(r"[6-9]\d{9}", d) else None


def valid_upi(s):
    return bool(re.fullmatch(r"[A-Za-z0-9._\-]{2,40}@[A-Za-z][A-Za-z0-9]{1,20}", s or ""))


def say(hi, en, kind="ok"):
    flash(f"{hi}|{en}", kind)


def safe_next(url):
    return url if url and url.startswith("/") and not url.startswith("//") else None


def login_required(f):
    @wraps(f)
    def inner(*a, **kw):
        if not g.user:
            say("पहले लॉगिन करें", "Please log in first", "err")
            return redirect(url_for("login", next=request.path))
        return f(*a, **kw)
    return inner


def role_required(role):
    def deco(f):
        @wraps(f)
        def inner(*a, **kw):
            if g.user["role"] != role:
                abort(403)
            return f(*a, **kw)
        return login_required(inner)
    return deco


IMG_MAGIC = {b"\xff\xd8\xff": "jpg", b"\x89PNG": "png"}


def save_photo(file, uid):
    """Save an uploaded photo if it is really a jpg/png/webp. Returns filename or None."""
    if not file or not file.filename:
        return None
    head = file.read(12)
    file.seek(0)
    ext = next((e for m, e in IMG_MAGIC.items() if head.startswith(m)), None)
    if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
        ext = "webp"
    if not ext:
        return None
    name = f"{uid}_{secrets.token_hex(6)}.{ext}"
    file.save(os.path.join(UPLOADS, name))
    return name


def remove_photo(name):
    if name:
        try:
            os.remove(os.path.join(UPLOADS, os.path.basename(name)))
        except OSError:
            pass


_fails = {}


def too_many_fails(phone):
    n, t = _fails.get(phone, (0, 0))
    if time.time() - t > 600:
        _fails.pop(phone, None)
        return False
    return n >= 5
