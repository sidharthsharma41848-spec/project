"""Bookings and UPI payments.

How the money flows (manual UPI, no payment gateway):
  1. Customer books a worker and agrees an amount.
  2. Customer pays that amount to the SITE's UPI ID and types the 12-digit UTR.
  3. Admin checks the bank/UPI statement and marks it verified   -> money is "held".
  4. Customer taps "work done" (or admin decides).
  5. Admin pays the worker (amount minus site commission) and saves the payout reference.
"""
import hashlib
import hmac
import json
import os
import re
import sqlite3

import razorpay

from flask import Blueprint, abort, g, redirect, render_template, request, url_for

from common import change, login_required, q, role_required, run, say, setting

bp = Blueprint("pay", __name__)

def razorpay_client():
    key_id = os.environ.get("RAZORPAY_KEY_ID", "").strip()
    key_secret = os.environ.get("RAZORPAY_KEY_SECRET", "").strip()
    if not key_id or not key_secret:
        return None
    return razorpay.Client(auth=(key_id, key_secret))

def razorpay_key_id():
    return os.environ.get("RAZORPAY_KEY_ID", "").strip()


def fetch(bid):
    b = q("""SELECT b.*, c.name cname, c.phone cphone, w.name wname, w.phone wphone, w.upi_id wupi
             FROM bookings b JOIN users c ON c.id=b.customer_id JOIN users w ON w.id=b.worker_id
             WHERE b.id=?""", (bid,), one=True)
    if not b:
        abort(404)
    if g.user["id"] not in (b["customer_id"], b["worker_id"]) and not g.user["is_admin"]:
        abort(403)
    return b


@bp.route("/book/<int:wid>", methods=["GET", "POST"])
@role_required("customer")
def book(wid):
    w = q("""SELECT u.id, u.name, u.city, u.upi_id, p.category FROM users u
             JOIN profiles p ON p.user_id=u.id WHERE u.id=? AND u.is_blocked=0""", (wid,), one=True)
    if not w:
        abort(404)
    if not razorpay_client() and (not setting("site_upi") or not w["upi_id"]):
        say("इस कारीगर से अभी ऑनलाइन बुकिंग नहीं हो सकती, फोन पर बात करें",
            "Online booking is not available for this worker yet. Please call.", "err")
        return redirect(url_for("worker", wid=wid))
    pct = int(setting("commission_pct") or 0)
    if request.method == "POST":
        desc = request.form.get("description", "").strip()[:500]
        try:
            amount = int(request.form.get("amount", "0"))
        except ValueError:
            amount = 0
        open_count = q("SELECT COUNT(*) c FROM bookings WHERE customer_id=? AND status='awaiting_payment'",
                       (g.user["id"],), one=True)["c"]
        if not 50 <= amount <= 100000 or len(desc) < 5:
            say("रकम (₹50 से ₹1,00,000) और काम की जानकारी सही भरें",
                "Enter an amount (₹50 to ₹1,00,000) and describe the work", "err")
        elif open_count >= 5:
            say("पहले पुरानी बुकिंग का पेमेंट करें या रद्द करें", "Please pay or cancel your old bookings first", "err")
        else:
            commission = (amount * pct + 50) // 100
            bid = run("""INSERT INTO bookings(customer_id, worker_id, description, amount, commission_pct, commission)
                         VALUES(?,?,?,?,?,?)""", (g.user["id"], wid, desc, amount, pct, commission))
            return redirect(url_for("pay.booking", bid=bid))
    return render_template("book.html", w=w, pct=pct, f=request.form)


@bp.route("/bookings")
@login_required
def bookings():
    col = "worker_id" if g.user["role"] == "worker" else "customer_id"
    rows = q(f"""SELECT b.*, c.name cname, w.name wname FROM bookings b
                 JOIN users c ON c.id=b.customer_id JOIN users w ON w.id=b.worker_id
                 WHERE b.{col}=? ORDER BY b.id DESC""", (g.user["id"],))
    return render_template("bookings.html", rows=rows)


@bp.route("/booking/<int:bid>")
@login_required
def booking(bid):
    b = fetch(bid)
    upi_link = ""
    if b["status"] == "awaiting_payment":
        from urllib.parse import quote
        upi_link = "upi://pay?pa={}&pn={}&am={}.00&cu=INR&tn={}".format(
            quote(setting("site_upi")), quote(setting("site_upi_name")), b["amount"], quote(f"Booking {b['id']}"))
    return render_template("booking.html", b=b, upi_link=upi_link, site_upi=setting("site_upi"),
                           site_name=setting("site_upi_name"), razorpay_key_id=razorpay_key_id(),
                           razorpay_enabled=bool(razorpay_client()))


@bp.route("/booking/<int:bid>/razorpay/order", methods=["POST"])
@role_required("customer")
def razorpay_order(bid):
    b = fetch(bid)
    client = razorpay_client()
    if not client:
        return {"error": "Razorpay is not configured on the server."}, 503
    if b["customer_id"] != g.user["id"] or b["status"] != "awaiting_payment":
        abort(403)
    if b["razorpay_order_id"]:
        return {"key_id": razorpay_key_id(), "order_id": b["razorpay_order_id"],
                "amount": int(b["amount"]) * 100, "currency": "INR", "name": "Karigar Saathi",
                "description": f"Booking #{b['id']}"}
    try:
        order = client.order.create(data={
            "amount": int(b["amount"]) * 100, "currency": "INR",
            "receipt": f"ks_booking_{b['id']}",
            "notes": {"booking_id": str(b["id"]), "customer_id": str(b["customer_id"])}
        })
        run("UPDATE bookings SET razorpay_order_id=?, payment_method='razorpay', updated=datetime('now') "
            "WHERE id=? AND status='awaiting_payment' AND razorpay_order_id=''", (order["id"], bid))
        saved = q("SELECT razorpay_order_id FROM bookings WHERE id=?", (bid,), one=True)
        return {"key_id": razorpay_key_id(), "order_id": saved["razorpay_order_id"],
                "amount": int(b["amount"]) * 100, "currency": "INR", "name": "Karigar Saathi",
                "description": f"Booking #{b['id']}"}
    except Exception:
        app_log = __import__("logging").getLogger(__name__)
        app_log.exception("Razorpay order creation failed for booking %s", bid)
        return {"error": "Payment could not be started. Please try again."}, 502


@bp.route("/booking/<int:bid>/razorpay/verify", methods=["POST"])
@role_required("customer")
def razorpay_verify(bid):
    b = fetch(bid)
    if b["customer_id"] != g.user["id"]:
        abort(403)
    if b["status"] == "held" and b["razorpay_payment_id"]:
        return {"ok": True, "message": "Payment already verified."}
    if b["status"] != "awaiting_payment" or not b["razorpay_order_id"]:
        return {"error": "Booking is not awaiting a Razorpay payment."}, 409
    data = request.get_json(silent=True) or {}
    payment_id = str(data.get("razorpay_payment_id", ""))[:100]
    order_id = str(data.get("razorpay_order_id", ""))[:100]
    signature = str(data.get("razorpay_signature", ""))[:256]
    if not payment_id or order_id != b["razorpay_order_id"] or not signature:
        return {"error": "Payment details are incomplete or do not match this booking."}, 400
    client = razorpay_client()
    if not client:
        return {"error": "Razorpay is not configured on the server."}, 503
    try:
        client.utility.verify_payment_signature({"razorpay_order_id": b["razorpay_order_id"],
            "razorpay_payment_id": payment_id, "razorpay_signature": signature})
        payment = client.payment.fetch(payment_id)
        if payment.get("order_id") != b["razorpay_order_id"] or int(payment.get("amount", -1)) != int(b["amount"]) * 100:
            return {"error": "Payment amount/order does not match this booking."}, 400
        if payment.get("status") != "captured" or not payment.get("captured"):
            return {"error": "Payment is not captured yet. Please wait and refresh."}, 409
        ok = change("UPDATE bookings SET status='held', razorpay_payment_id=?, utr=?, payment_method='razorpay', updated=datetime('now') "
                    "WHERE id=? AND status='awaiting_payment' AND razorpay_order_id=?",
                    (payment_id, payment_id, bid, b["razorpay_order_id"]))
        if not ok:
            latest = q("SELECT status, razorpay_payment_id FROM bookings WHERE id=?", (bid,), one=True)
            if latest and latest["status"] == "held" and latest["razorpay_payment_id"] == payment_id:
                return {"ok": True, "message": "Payment already verified."}
            return {"error": "Booking status changed. Contact support if money was deducted."}, 409
        return {"ok": True, "message": "Payment verified successfully."}
    except razorpay.errors.SignatureVerificationError:
        return {"error": "Payment signature verification failed."}, 400
    except Exception:
        __import__("logging").getLogger(__name__).exception("Razorpay verification failed for booking %s", bid)
        return {"error": "Could not verify payment right now. Do not pay again; refresh or contact support."}, 502


@bp.route("/booking/<int:bid>/pay", methods=["POST"])
@role_required("customer")
def pay(bid):
    b = fetch(bid)
    utr = re.sub(r"\s", "", request.form.get("utr", ""))
    if b["customer_id"] != g.user["id"] or b["status"] != "awaiting_payment":
        abort(403)
    if not re.fullmatch(r"\d{12}", utr):
        say("UTR 12 अंकों का होता है, पेमेंट ऐप में देखें", "UTR is 12 digits. Find it in your payment app.", "err")
        return redirect(url_for("pay.booking", bid=bid))
    try:
        ok = change("UPDATE bookings SET status='verifying', utr=?, updated=datetime('now') "
                    "WHERE id=? AND customer_id=? AND status='awaiting_payment'", (utr, bid, g.user["id"]))
    except sqlite3.IntegrityError:
        say("यह UTR पहले ही इस्तेमाल हो चुका है", "This UTR was already used", "err")
        return redirect(url_for("pay.booking", bid=bid))
    if ok:
        say("धन्यवाद! हम आपका पेमेंट जाँच रहे हैं", "Thank you! We are checking your payment")
    return redirect(url_for("pay.booking", bid=bid))


@bp.route("/booking/<int:bid>/done", methods=["POST"])
@role_required("customer")
def done(bid):
    b = fetch(bid)
    if b["customer_id"] != g.user["id"]:
        abort(403)
    if change("UPDATE bookings SET status='done', updated=datetime('now') WHERE id=? AND status='held'", (bid,)):
        say("ठीक है, कारीगर को पैसा भेजा जाएगा", "Thanks, the worker will be paid")
    return redirect(url_for("pay.booking", bid=bid))


@bp.route("/booking/<int:bid>/cancel", methods=["POST"])
@role_required("customer")
def cancel(bid):
    b = fetch(bid)
    if b["customer_id"] != g.user["id"]:
        abort(403)
    if change("UPDATE bookings SET status='cancelled', updated=datetime('now') "
              "WHERE id=? AND status='awaiting_payment'", (bid,)):
        say("बुकिंग रद्द हो गई", "Booking cancelled")
    return redirect(url_for("pay.bookings"))


@bp.route("/webhooks/razorpay", methods=["POST"])
def razorpay_webhook():
    """Razorpay webhook: independently confirm captured payments even if checkout closes."""
    secret = os.environ.get("RAZORPAY_WEBHOOK_SECRET", "").strip()
    signature = request.headers.get("X-Razorpay-Signature", "")
    body = request.get_data(cache=True)
    if not secret or not signature:
        abort(400)
    expected = hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, signature):
        abort(400)
    try:
        event = json.loads(body.decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        abort(400)
    if event.get("event") not in ("payment.captured", "order.paid"):
        return {"ok": True, "ignored": True}
    payload = event.get("payload") or {}
    payment = (payload.get("payment") or {}).get("entity") or {}
    order = (payload.get("order") or {}).get("entity") or {}
    order_id = str(payment.get("order_id") or order.get("id") or "")
    payment_id = str(payment.get("id") or "")
    if not order_id or not payment_id or payment.get("status") != "captured":
        # order.paid can arrive without a payment entity; verify through API rather than trusting it.
        if event.get("event") == "order.paid" and order_id and razorpay_client():
            try:
                client = razorpay_client()
                payments = client.order.payments(order_id)
                captured = next((x for x in payments.get("items", []) if x.get("status") == "captured"), None)
                if captured:
                    payment = captured
                    payment_id = str(captured.get("id") or "")
                    order_id = str(captured.get("order_id") or order_id)
            except Exception:
                __import__("logging").getLogger(__name__).exception("Could not fetch payments for Razorpay order webhook")
        if not order_id or not payment_id or payment.get("status") != "captured":
            return {"ok": True, "ignored": True}
    booking = q("SELECT id, amount, status, razorpay_payment_id FROM bookings WHERE razorpay_order_id=?",
                (order_id,), one=True)
    if not booking:
        return {"ok": True, "ignored": True}
    if int(payment.get("amount", -1)) != int(booking["amount"]) * 100:
        __import__("logging").getLogger(__name__).error("Razorpay webhook amount mismatch for booking %s", booking["id"])
        return {"error": "Amount mismatch"}, 400
    if booking["status"] == "held" and booking["razorpay_payment_id"] == payment_id:
        return {"ok": True, "duplicate": True}
    change("UPDATE bookings SET status='held', razorpay_payment_id=?, utr=?, payment_method='razorpay', updated=datetime('now') "
           "WHERE id=? AND status='awaiting_payment' AND razorpay_order_id=?",
           (payment_id, payment_id, booking["id"], order_id))
    return {"ok": True}
