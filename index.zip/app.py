"""कारीगर साथी / Karigar Saathi - workers and engineers hiring website (Flask + SQLite)."""
import os
import secrets
import time

from flask import (Flask, abort, flash, g, redirect, render_template,
                   request, session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

from common import (BASE, GROUPS, STATUS, _fails, clean_phone, close_db, init_db, load_cats,
                    login_required, q, remove_photo, role_required, run, safe_next, save_photo,
                    say, setting, too_many_fails, valid_upi)

app = Flask(__name__)
_keyfile = os.path.join(BASE, ".secret_key")
if not os.path.exists(_keyfile):
    with open(_keyfile, "w") as f:
        f.write(secrets.token_hex(32))
with open(_keyfile) as f:
    app.secret_key = f.read().strip()
app.config.update(MAX_CONTENT_LENGTH=2 * 1024 * 1024,
                  SESSION_COOKIE_HTTPONLY=True,
                  SESSION_COOKIE_SAMESITE="Lax")
app.teardown_appcontext(close_db)
app.jinja_env.filters["rupee"] = lambda n: "₹{:,}".format(int(n or 0))

# ------------------------------------------------------------ request hooks
@app.before_request
def load_user():
    g.user = None
    uid = session.get("uid")
    if uid:
        g.user = q("SELECT * FROM users WHERE id=?", (uid,), one=True)
        if g.user and g.user["is_blocked"]:
            g.user = None
            session.pop("uid", None)
    load_cats()
    if "csrf" not in session:
        session["csrf"] = secrets.token_hex(16)
    if request.method == "POST" and request.endpoint != "pay.razorpay_webhook":
        if not secrets.compare_digest(request.form.get("csrf", "") or request.headers.get("X-CSRF-Token", ""), session["csrf"]):
            abort(400)

@app.after_request
def headers(resp):
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["X-Frame-Options"] = "DENY"
    resp.headers["Content-Security-Policy"] = (
        "default-src 'self'; script-src 'self' https://checkout.razorpay.com; "
        "style-src 'self' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; "
        "img-src 'self' data:; connect-src 'self' https://api.razorpay.com; "
        "frame-src 'self' https://api.razorpay.com https://checkout.razorpay.com; form-action 'self'")
    return resp

@app.context_processor
def inject():
    unread = 0
    if g.get("user"):
        unread = q("SELECT COUNT(*) c FROM messages WHERE receiver_id=? AND is_read=0",
                   (g.user["id"],), one=True)["c"]
    return dict(me=g.get("user"), CAT=g.CAT, CATEGORIES=g.CATS, GROUPS=GROUPS, STATUS=STATUS,
                csrf=session.get("csrf", ""), unread=unread)

@app.errorhandler(400)
@app.errorhandler(403)
@app.errorhandler(404)
@app.errorhandler(413)
def oops(e):
    msgs = {400: ("कुछ गड़बड़ हुई, पेज दोबारा खोलें", "Something went wrong. Please reopen the page."),
            403: ("आपको यहाँ आने की अनुमति नहीं है", "You are not allowed here."),
            404: ("यह पेज नहीं मिला", "This page was not found."),
            413: ("फोटो बहुत बड़ी है (2 MB से कम रखें)", "Photo is too big (keep it under 2 MB).")}
    hi, en = msgs.get(e.code, msgs[400])
    return render_template("error.html", hi=hi, en=en), e.code

# -------------------------------------------------------------------- pages
@app.route("/")
def home():
    counts = {r["category"]: r["c"] for r in
              q("SELECT category, COUNT(*) c FROM profiles GROUP BY category")}
    return render_template("home.html", counts=counts)

WORKER_SQL = """
SELECT u.id, u.name, u.city, p.category, p.experience, p.rate, p.photo,
  (SELECT ROUND(AVG(stars),1) FROM reviews WHERE worker_id=u.id) rating,
  (SELECT COUNT(*) FROM reviews WHERE worker_id=u.id) nrev
FROM users u JOIN profiles p ON p.user_id=u.id AND u.is_blocked=0
"""

@app.route("/find/<group>")
def find(group):
    if group not in GROUPS:
        abort(404)
    slugs = [c["slug"] for c in g.CATS if c["group"] == group]
    cat = request.args.get("cat", "")
    city = request.args.get("city", "").strip()[:60]
    use = [cat] if cat in slugs else slugs
    sql = WORKER_SQL + f" WHERE p.category IN ({','.join('?' * len(use))})"
    args = list(use)
    if city:
        sql += " AND u.city LIKE ?"
        args.append(f"%{city}%")
    sql += " ORDER BY (rating IS NULL), rating DESC, nrev DESC, u.id DESC LIMIT 100"
    return render_template("find.html", group=group, cat=cat if cat in slugs else "",
                           city=city, people=q(sql, args),
                           cats=[c for c in g.CATS if c["group"] == group])

@app.route("/worker/<int:wid>")
def worker(wid):
    w = q(WORKER_SQL + " WHERE u.id=?", (wid,), one=True)
    if not w:
        abort(404)
    full = q("SELECT u.phone, u.upi_id, p.about FROM users u JOIN profiles p ON p.user_id=u.id WHERE u.id=?",
             (wid,), one=True)
    reviews = q("""SELECT r.stars, r.comment, r.created, u.name FROM reviews r
                   JOIN users u ON u.id=r.customer_id WHERE r.worker_id=? ORDER BY r.id DESC""", (wid,))
    mine = None
    if g.user and g.user["role"] == "customer":
        mine = q("SELECT * FROM reviews WHERE worker_id=? AND customer_id=?",
                 (wid, g.user["id"]), one=True)
    razorpay_ready = bool(os.environ.get("RAZORPAY_KEY_ID", "").strip() and os.environ.get("RAZORPAY_KEY_SECRET", "").strip())
    can_book = razorpay_ready or (bool(full["upi_id"]) and bool(setting("site_upi")))
    return render_template("worker.html", w=w, full=full, reviews=reviews, mine=mine, can_book=can_book)

@app.route("/worker/<int:wid>/review", methods=["POST"])
@role_required("customer")
def review(wid):
    if not q("SELECT 1 FROM profiles WHERE user_id=?", (wid,), one=True):
        abort(404)
    try:
        stars = int(request.form.get("stars", 0))
    except ValueError:
        stars = 0
    if not 1 <= stars <= 5:
        say("स्टार चुनें", "Please choose stars", "err")
        return redirect(url_for("worker", wid=wid))
    comment = request.form.get("comment", "").strip()[:300]
    run("""INSERT INTO reviews(worker_id, customer_id, stars, comment) VALUES(?,?,?,?)
           ON CONFLICT(worker_id, customer_id) DO UPDATE SET stars=excluded.stars,
           comment=excluded.comment, created=date('now')""",
        (wid, g.user["id"], stars, comment))
    say("आपकी रेटिंग सेव हो गई", "Your rating is saved")
    return redirect(url_for("worker", wid=wid))

# --------------------------------------------------------- register / login
@app.route("/register", methods=["GET", "POST"])
def register():
    if g.user:
        return redirect(url_for("dashboard"))
    form = request.form if request.method == "POST" else request.args
    if request.method == "POST":
        role = form.get("role", "")
        name = form.get("name", "").strip()[:60]
        phone = clean_phone(form.get("phone"))
        city = form.get("city", "").strip()[:60]
        pw = form.get("password", "")
        cat = form.get("category", "")
        err = None
        if role not in ("worker", "customer"):
            err = ("बताएं कि आपको काम चाहिए या कारीगर", "Choose: you need work, or you need a worker")
        elif not name or not city:
            err = ("नाम और शहर भरें", "Please fill your name and city")
        elif not phone:
            err = ("10 अंक का सही मोबाइल नंबर डालें", "Enter a correct 10-digit mobile number")
        elif len(pw) < 6:
            err = ("पासवर्ड कम से कम 6 अक्षर का रखें", "Password must be at least 6 characters")
        elif role == "worker" and cat not in g.ACTIVE:
            err = ("अपना काम चुनें", "Choose your work")
        elif q("SELECT 1 FROM users WHERE phone=?", (phone,), one=True):
            err = ("यह नंबर पहले से रजिस्टर है, लॉगिन करें", "This number is already registered. Please log in.")
        if err:
            say(*err, "err")
            return render_template("register.html", f=form)
        uid = run("INSERT INTO users(phone,name,password_hash,role,city) VALUES(?,?,?,?,?)",
                  (phone, name, generate_password_hash(pw), role, city))
        if role == "worker":
            run("INSERT INTO profiles(user_id, category) VALUES(?,?)", (uid, cat))
        session.clear()
        session["uid"] = uid
        say("रजिस्ट्रेशन हो गया! स्वागत है", "Registered! Welcome")
        return redirect(url_for("dashboard"))
    return render_template("register.html", f=form)

@app.route("/login", methods=["GET", "POST"])
def login():
    if g.user:
        return redirect(url_for("dashboard"))
    nxt = safe_next(request.values.get("next"))
    if request.method == "POST":
        phone = clean_phone(request.form.get("phone")) or ""
        if too_many_fails(phone):
            say("बहुत बार गलत कोशिश हुई, 10 मिनट बाद फिर करें", "Too many wrong tries. Try again after 10 minutes.", "err")
            return render_template("login.html", next=nxt)
        u = q("SELECT * FROM users WHERE phone=?", (phone,), one=True)
        if u and u["is_blocked"]:
            say("यह खाता बंद है, हमसे संपर्क करें", "This account is blocked. Please contact us.", "err")
            return render_template("login.html", next=nxt)
        if u and check_password_hash(u["password_hash"], request.form.get("password", "")):
            _fails.pop(phone, None)
            session.clear()
            session["uid"] = u["id"]
            return redirect(nxt or url_for("dashboard"))
        n, _ = _fails.get(phone, (0, 0))
        _fails[phone] = (n + 1, time.time())
        say("नंबर या पासवर्ड गलत है", "Wrong number or password", "err")
    return render_template("login.html", next=nxt)

@app.route("/logout", methods=["POST"])
def logout():
    session.clear()
    say("आप लॉग आउट हो गए", "You are logged out")
    return redirect(url_for("home"))

# ---------------------------------------------------------------- dashboard
@app.route("/dashboard")
@login_required
def dashboard():
    if g.user["role"] == "worker":
        p = q("SELECT * FROM profiles WHERE user_id=?", (g.user["id"],), one=True)
        stats = q("SELECT COUNT(*) n, ROUND(AVG(stars),1) a FROM reviews WHERE worker_id=?",
                  (g.user["id"],), one=True)
        return render_template("dashboard_worker.html", p=p, stats=stats)
    jobs = q("SELECT * FROM jobs WHERE customer_id=? ORDER BY id DESC", (g.user["id"],))
    return render_template("dashboard_customer.html", jobs=jobs)

@app.route("/profile", methods=["POST"])
@role_required("worker")
def profile():
    f = request.form
    name = f.get("name", "").strip()[:60]
    city = f.get("city", "").strip()[:60]
    cat = f.get("category", "")
    try:
        exp = max(0, min(60, int(f.get("experience", 0) or 0)))
    except ValueError:
        exp = 0
    p = q("SELECT * FROM profiles WHERE user_id=?", (g.user["id"],), one=True)
    upi = f.get("upi_id", "").strip()[:60]
    if not name or not city or (cat not in g.ACTIVE and cat != p["category"]):
        say("नाम, शहर और काम भरें", "Please fill name, city and work", "err")
        return redirect(url_for("dashboard"))
    if upi and not valid_upi(upi):
        say("UPI ID सही नहीं है (जैसे: naam@upi)", "UPI ID is not valid (e.g. name@upi)", "err")
        return redirect(url_for("dashboard"))
    photo = p["photo"]
    new = save_photo(request.files.get("photo"), g.user["id"])
    if request.files.get("photo") and request.files["photo"].filename and not new:
        say("फोटो JPG, PNG या WEBP होनी चाहिए", "Photo must be JPG, PNG or WEBP", "err")
    if new:
        remove_photo(photo)
        photo = new
    run("UPDATE users SET name=?, city=?, upi_id=? WHERE id=?", (name, city, upi, g.user["id"]))
    run("UPDATE profiles SET category=?, experience=?, rate=?, about=?, photo=? WHERE user_id=?",
        (cat, exp, f.get("rate", "").strip()[:60], f.get("about", "").strip()[:500], photo, g.user["id"]))
    say("प्रोफाइल सेव हो गई", "Profile saved")
    return redirect(url_for("dashboard"))

# --------------------------------------------------------------------- jobs
@app.route("/jobs")
@login_required
def jobs():
    if g.user["role"] != "worker":
        return redirect(url_for("dashboard"))
    p = q("SELECT category FROM profiles WHERE user_id=?", (g.user["id"],), one=True)
    show_all = request.args.get("all") == "1"
    sql = """SELECT j.*, u.name customer FROM jobs j JOIN users u ON u.id=j.customer_id AND u.is_blocked=0
             WHERE j.status='open'"""
    args = []
    if not show_all and p:
        sql += " AND j.category=?"
        args.append(p["category"])
    sql += " ORDER BY j.id DESC LIMIT 100"
    return render_template("jobs.html", items=q(sql, args), show_all=show_all, mine=p)

@app.route("/jobs/new", methods=["GET", "POST"])
@role_required("customer")
def job_new():
    if request.method == "POST":
        f = request.form
        cat = f.get("category", "")
        city = f.get("city", "").strip()[:60]
        desc = f.get("description", "").strip()[:500]
        phone = clean_phone(f.get("phone"))
        if cat not in g.ACTIVE or not city or len(desc) < 5 or not phone:
            say("सब जानकारी सही भरें", "Please fill everything correctly", "err")
            return render_template("job_new.html", f=f)
        run("INSERT INTO jobs(customer_id, category, city, description, phone) VALUES(?,?,?,?,?)",
            (g.user["id"], cat, city, desc, phone))
        say("आपका काम डाल दिया गया", "Your job is posted")
        return redirect(url_for("dashboard"))
    return render_template("job_new.html", f={"city": g.user["city"], "phone": g.user["phone"],
                                              "category": request.args.get("cat", "")})

@app.route("/jobs/<int:jid>/close", methods=["POST"])
@role_required("customer")
def job_close(jid):
    run("UPDATE jobs SET status='closed' WHERE id=? AND customer_id=?", (jid, g.user["id"]))
    say("काम बंद कर दिया", "Job closed")
    return redirect(url_for("dashboard"))

# ----------------------------------------------------------------- messages
@app.route("/messages")
@login_required
def inbox():
    me = g.user["id"]
    rows = q("""SELECT u.id, u.name, m.body, m.created,
                  (SELECT COUNT(*) FROM messages WHERE sender_id=u.id AND receiver_id=? AND is_read=0) unread
                FROM users u JOIN messages m ON m.id=(
                  SELECT MAX(id) FROM messages
                  WHERE (sender_id=u.id AND receiver_id=?) OR (sender_id=? AND receiver_id=u.id))
                WHERE u.id != ? ORDER BY m.id DESC""", (me, me, me, me))
    return render_template("inbox.html", rows=rows)

@app.route("/messages/<int:uid>", methods=["GET", "POST"])
@login_required
def thread(uid):
    me = g.user["id"]
    other = q("SELECT id, name, phone, role FROM users WHERE id=?", (uid,), one=True)
    if not other or uid == me:
        abort(404)
    if request.method == "POST":
        body = request.form.get("body", "").strip()[:500]
        if body:
            run("INSERT INTO messages(sender_id, receiver_id, body) VALUES(?,?,?)", (me, uid, body))
        return redirect(url_for("thread", uid=uid) + "#end")
    run("UPDATE messages SET is_read=1 WHERE sender_id=? AND receiver_id=?", (uid, me))
    msgs = q("""SELECT * FROM messages WHERE (sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?)
                ORDER BY id""", (me, uid, uid, me))
    return render_template("thread.html", other=other, msgs=msgs)


import admin as _admin      # noqa: E402  (admin panel at /admin)
import payments as _pay     # noqa: E402  (bookings and UPI payments)
app.register_blueprint(_admin.bp)
app.register_blueprint(_pay.bp)

init_db()

if __name__ == "__main__":
    app.run(host=os.environ.get("HOST", "127.0.0.1"), port=int(os.environ.get("PORT", 5000)), debug=False)
