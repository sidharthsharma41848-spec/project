"""Make an existing user an admin.   Usage: python make_admin.py 9876543210
(Register on the website first, then run this with that mobile number.)"""
import sys
import common

if len(sys.argv) != 2:
    sys.exit(__doc__)
common.init_db()
phone = common.clean_phone(sys.argv[1])
if not phone:
    sys.exit("That is not a valid 10-digit mobile number.")
import sqlite3
con = sqlite3.connect(common.DB)
n = con.execute("UPDATE users SET is_admin=1 WHERE phone=?", (phone,)).rowcount
con.commit()
print("Done. Admin panel: /admin" if n else "No user with that number. Register on the website first.")
