"""Optional: adds sample workers so the site does not look empty. Run once: python demo_data.py
All demo accounts use password: demo1234"""
from werkzeug.security import generate_password_hash
import app

DEMO = [
    ("Ramesh Kumar", "9000000001", "Patna", "carpenter", 8, "₹700 रोज़ / per day", "फर्नीचर, दरवाज़े, खिड़की का काम।"),
    ("Sunil Yadav", "9000000002", "Patna", "plumber", 5, "₹500 रोज़ / per day", "नल, पाइप, बाथरूम फिटिंग।"),
    ("Anwar Ali", "9000000003", "Gaya", "mechanic", 12, "₹600 रोज़ / per day", "बाइक और गाड़ी की मरम्मत।"),
    ("Pooja Kumari", "9000000004", "Patna", "tailor", 6, "₹150 प्रति कपड़ा / per piece", "सिलाई और कढ़ाई।"),
    ("Er. Amit Singh", "9000000005", "Patna", "civil-eng", 7, "₹1500 प्रति दिन / per day", "घर का नक्शा, निर्माण की देखरेख।"),
    ("Er. Neha Sharma", "9000000006", "Gaya", "electrical-eng", 4, "₹1200 प्रति दिन / per day", "वायरिंग डिज़ाइन और लोड जाँच।"),
    ("Mohan Lal", "9000000007", "Patna", "electrician", 10, "₹650 रोज़ / per day", "घर और दुकान की वायरिंग।"),
]
with app.app.app_context():
    for name, phone, city, cat, exp, rate, about in DEMO:
        if app.q("SELECT 1 FROM users WHERE phone=?", (phone,), one=True):
            continue
        uid = app.run("INSERT INTO users(phone,name,password_hash,role,city,upi_id) VALUES(?,?,?,?,?,?)",
                      (phone, name, generate_password_hash("demo1234"), "worker", city, phone + "@upi"))
        app.run("INSERT INTO profiles(user_id,category,experience,rate,about) VALUES(?,?,?,?,?)",
                (uid, cat, exp, rate, about))
print("Demo data added.")
