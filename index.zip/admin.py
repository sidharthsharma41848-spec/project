"""Admin panel at /admin - manage users, jobs, reviews, payments, categories and settings."""
import re
import sqlite3

from flask import Blueprint, abort, g, redirect, render_template, request, url_for

from common import (STATUS, audit, change, q, remove_photo, run, say, set_setting, setting,
                    valid_upi)

bp = Blueprint("admin", __name__, url_prefix="/admin")


@bp.before_request
def guard():
    if not g.user:
        say("पहले लॉगिन करें", "Please log in first", "err")
        return redirect(url_for("login", next=request.path))
    if not g.user["is_admin"]:
        abort(403)


def back(endpoint, **kw):
    return redirect(url_for(endpoint, **kw))


@bp.route("/", strict_slashes=False)
def index():
    one = lambda sql: q(sql, one=True)[0]
    stats = dict(
        workers=one("SELECT COUNT(*) FROM users WHERE role='worker'"),
        customers=one("SELECT COUNT(*) FROM users WHERE role='customer'"),
        blocked=one("SELECT COUNT(*) FROM users WHERE is_blocked=1"),
        open_jobs=one("SELECT COUNT(*) FROM jobs WHERE status='open'"),
        to_verify=one("SELECT COUNT(*) FROM bookings WHERE status='verifying'"),
        to_pay=one("SELECT COUNT(*) FROM bookings WHERE status='done'"),
        held=one("SELECT COALESCE(SUM(amount),0) FROM bookings WHERE status IN ('verifying','held','done')"),
        earned=one("SELECT COALESCE(SUM(commission),0) FROM bookings WHERE status='released'"),
        reviews=one("SELECT COUNT(*) FROM reviews"),
    )
    return render_template("admin/index.html", s=stats)


# -------------------------------------------------------------------- users
@bp.route("/users")
def users():
    term = request.args.get("q", "").strip()[:60]
    role = request.args.get("role", "")
    sql = "SELECT * FROM users WHERE 1=1"
    args = []
    if term:
        sql += " AND (name LIKE ? OR phone LIKE ? OR city LIKE ?)"
        args += [f"%{term}%"] * 3
    if role in ("worker", "customer"):
        sql += " AND role=?"
        args.append(role)
    return render_template("admin/users.html", rows=q(sql + " ORDER BY id DESC LIMIT 200", args), term=term, role=role)


@bp.route("/users/<int:uid>/<action>", methods=["POST"])
def user_action(uid, action):
    u = q("SELECT * FROM users WHERE id=?", (uid,), one=True)
    if not u:
        abort(404)
    me = g.user["id"]
    if uid == me and action in ("block", "delete", "removeadmin"):
        say("अपने आप पर यह नहीं कर सकते", "You cannot do this to yourself", "err")
    elif action == "block":
        run("UPDATE users SET is_blocked=1 WHERE id=?", (uid,))
        audit("block user", f"#{uid} {u['name']}")
        say("यूज़र ब्लॉक हुआ", "User blocked")
    elif action == "unblock":
        run("UPDATE users SET is_blocked=0 WHERE id=?", (uid,))
        audit("unblock user", f"#{uid} {u['name']}")
        say("यूज़र खुल गया", "User unblocked")
    elif action == "makeadmin":
        run("UPDATE users SET is_admin=1 WHERE id=?", (uid,))
        audit("make admin", f"#{uid} {u['name']}")
        say("अब यह एडमिन है", "User is now an admin")
    elif action == "removeadmin":
        run("UPDATE users SET is_admin=0 WHERE id=?", (uid,))
        audit("remove admin", f"#{uid} {u['name']}")
        say("एडमिन हटाया", "Admin rights removed")
    elif action == "delete":
        p = q("SELECT photo FROM profiles WHERE user_id=?", (uid,), one=True)
        try:
            run("DELETE FROM users WHERE id=?", (uid,))
        except sqlite3.IntegrityError:
            say("इससे पेमेंट जुड़े हैं, मिटा नहीं सकते। ब्लॉक करें।",
                "This user has payment records, so it cannot be deleted. Block instead.", "err")
        else:
            if p:
                remove_photo(p["photo"])
            audit("delete user", f"#{uid} {u['name']} {u['phone']}")
            say("यूज़र मिटा दिया", "User deleted")
    else:
        abort(404)
    return redirect(request.referrer or url_for("admin.users"))


# --------------------------------------------------------------- jobs/reviews
@bp.route("/jobs")
def jobs():
    rows = q("""SELECT j.*, u.name customer FROM jobs j JOIN users u ON u.id=j.customer_id
                ORDER BY j.id DESC LIMIT 200""")
    return render_template("admin/jobs.html", rows=rows)


@bp.route("/jobs/<int:jid>/<action>", methods=["POST"])
def job_action(jid, action):
    if action == "close":
        run("UPDATE jobs SET status='closed' WHERE id=?", (jid,))
    elif action == "delete":
        run("DELETE FROM jobs WHERE id=?", (jid,))
    else:
        abort(404)
    audit(f"{action} job", f"#{jid}")
    say("हो गया", "Done")
    return back("admin.jobs")


@bp.route("/reviews")
def reviews():
    rows = q("""SELECT r.*, c.name customer, w.name worker FROM reviews r
                JOIN users c ON c.id=r.customer_id JOIN users w ON w.id=r.worker_id
                ORDER BY r.id DESC LIMIT 200""")
    return render_template("admin/reviews.html", rows=rows)


@bp.route("/reviews/<int:rid>/delete", methods=["POST"])
def review_delete(rid):
    run("DELETE FROM reviews WHERE id=?", (rid,))
    audit("delete review", f"#{rid}")
    say("रिव्यू हटा दिया", "Review deleted")
    return back("admin.reviews")


# ----------------------------------------------------------------- bookings
@bp.route("/bookings")
def bookings():
    st = request.args.get("status", "")
    sql = """SELECT b.*, c.name cname, c.phone cphone, w.name wname, w.phone wphone, w.upi_id wupi
             FROM bookings b JOIN users c ON c.id=b.customer_id JOIN users w ON w.id=b.worker_id"""
    args = []
    if st in STATUS:
        sql += " WHERE b.status=?"
        args.append(st)
    return render_template("admin/bookings.html", rows=q(sql + " ORDER BY b.id DESC LIMIT 200", args), st=st)


# action -> (statuses it may start from, new status)
BOOKING_FLOW = {
    "verify": (("verifying",), "held"),
    "reject": (("verifying",), "awaiting_payment"),
    "release": (("held", "done"), "released"),
    "refund": (("verifying", "held", "done"), "refunded"),
    "cancel": (("awaiting_payment",), "cancelled"),
}


@bp.route("/bookings/<int:bid>/<action>", methods=["POST"])
def booking_action(bid, action):
    if action not in BOOKING_FLOW:
        abort(404)
    ref = request.form.get("ref", "").strip()[:80]
    if action in ("release", "refund") and len(ref) < 4:
        say("पैसा भेजने का UTR / नोट लिखें", "Enter the UTR or a note for this payment", "err")
        return back("admin.bookings")
    froms, new = BOOKING_FLOW[action]
    marks = ",".join("?" * len(froms))
    extra = ", utr=''" if action == "reject" else ""
    ok = change(f"""UPDATE bookings SET status=?, payout_ref=CASE WHEN ?!='' THEN ? ELSE payout_ref END,
                    updated=datetime('now'){extra} WHERE id=? AND status IN ({marks})""",
                (new, ref, ref, bid, *froms))
    if ok:
        audit(f"booking {action}", f"#{bid} {ref}")
        say("हो गया", "Done")
    else:
        say("यह बुकिंग इस स्थिति में नहीं है", "This booking is not in the right state", "err")
    return redirect(url_for("admin.bookings", status=request.args.get("status", "")))


# --------------------------------------------------------------- categories
@bp.route("/categories", methods=["GET", "POST"])
def categories():
    if request.method == "POST":
        slug = request.form.get("slug", "").strip().lower()
        hi = request.form.get("hi", "").strip()[:40]
        en = request.form.get("en", "").strip()[:40]
        icon = request.form.get("icon", "").strip()[:8] or "🛠️"
        grp = request.form.get("grp", "")
        if not re.fullmatch(r"[a-z0-9-]{2,30}", slug) or not hi or not en or grp not in ("worker", "engineer", "medical", "equipment"):
            say("स्लग (a-z, 0-9, -), हिंदी नाम, English नाम और ग्रुप भरें",
                "Fill slug (a-z, 0-9, -), Hindi name, English name and group", "err")
        elif q("SELECT 1 FROM categories WHERE slug=?", (slug,), one=True):
            say("यह स्लग पहले से है", "This slug already exists", "err")
        else:
            top = q("SELECT COALESCE(MAX(sort),0)+1 n FROM categories", one=True)["n"]
            run("INSERT INTO categories(slug,hi,en,icon,grp,sort) VALUES(?,?,?,?,?,?)", (slug, hi, en, icon, grp, top))
            audit("add category", slug)
            say("नया सेक्शन जुड़ गया", "Section added")
        return back("admin.categories")
    rows = q("""SELECT c.*, (SELECT COUNT(*) FROM profiles p WHERE p.category=c.slug) n
                FROM categories c ORDER BY grp DESC, sort""")
    return render_template("admin/categories.html", rows=rows)


@bp.route("/categories/<slug>", methods=["POST"])
def category_edit(slug):
    c = q("SELECT * FROM categories WHERE slug=?", (slug,), one=True)
    if not c:
        abort(404)
    if request.form.get("do") == "toggle":
        run("UPDATE categories SET active=1-active WHERE slug=?", (slug,))
        audit("toggle category", slug)
    else:
        hi = request.form.get("hi", "").strip()[:40] or c["hi"]
        en = request.form.get("en", "").strip()[:40] or c["en"]
        icon = request.form.get("icon", "").strip()[:8] or c["icon"]
        try:
            sort = int(request.form.get("sort", c["sort"]))
        except ValueError:
            sort = c["sort"]
        run("UPDATE categories SET hi=?, en=?, icon=?, sort=? WHERE slug=?", (hi, en, icon, sort, slug))
        audit("edit category", slug)
    say("सेव हो गया", "Saved")
    return back("admin.categories")


# ----------------------------------------------------------------- settings
@bp.route("/settings", methods=["GET", "POST"])
def settings():
    if request.method == "POST":
        pct = request.form.get("commission_pct", "").strip()
        upi = request.form.get("site_upi", "").strip()
        name = request.form.get("site_upi_name", "").strip()[:40] or "Karigar Saathi"
        if not pct.isdigit() or not 0 <= int(pct) <= 50:
            say("कमीशन 0 से 50 के बीच रखें", "Commission must be between 0 and 50", "err")
        elif upi and not valid_upi(upi):
            say("UPI ID सही नहीं है", "UPI ID is not valid", "err")
        else:
            set_setting("commission_pct", str(int(pct)))
            set_setting("site_upi", upi)
            set_setting("site_upi_name", name)
            audit("settings", f"commission={pct}% upi={upi}")
            say("सेटिंग सेव हो गई", "Settings saved")
        return back("admin.settings")
    return render_template("admin/settings.html", pct=setting("commission_pct"), upi=setting("site_upi"),
                           name=setting("site_upi_name"))


@bp.route("/log")
def log():
    rows = q("""SELECT a.*, u.name admin FROM audit a LEFT JOIN users u ON u.id=a.admin_id
                ORDER BY a.id DESC LIMIT 200""")
    return render_template("admin/log.html", rows=rows)
