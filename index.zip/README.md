# कारीगर साथी / Karigar Saathi

Workers, engineers, doctors, medical services aur construction machinery/equipment providers ko customers se jodne wali website.
Python Flask + SQLite database. Hindi + English. Razorpay Checkout integration (test/live keys configured through environment variables).

## Naye sections aur design

- Professional responsive home page, animated hero artwork, floating service icons, hover effects, reveal animations, mobile layouts.
- New listings: Doctors, dentists, nurses, physiotherapists, lab technicians and ambulance services.
- New equipment listings: JCB/excavator, crane, tractor, concrete mixer, generator, welding machine, scaffolding/shuttering and water tanker.
- Existing database is upgraded automatically to support medical/equipment categories; existing profiles and bookings are retained.
- Doctor and machine listings are marketplace listings, not a guarantee of professional credentials, machine condition, operator, insurance or availability. Verify these directly before booking.

## Chalane ka tareeka

1. Python 3.9+ install ho. Terminal is folder mein kholo.
2. `pip install -r requirements.txt`
3. (Optional) demo workers: `python demo_data.py`  (password: demo1234)
4. `python app.py`  ->  browser mein http://127.0.0.1:5000

Phone se test (same WiFi): `HOST=0.0.0.0 python app.py`, phir phone mein `http://<computer-ka-IP>:5000`.

## Admin banane ka tareeka

1. Website par apne mobile number se Register karo (customer ya worker, koi bhi).
2. Terminal mein: `python make_admin.py 9876543210`  (apna number)
3. Logout/login karo. Upar "⚙️ Admin" dikhega ya seedha `/admin` kholo.
4. **Admin > Settings** mein apni UPI ID aur commission % dalo. Iske baad hi online booking chalu hogi.

Admin panel mein: Dashboard, Payments, Users (block/delete/admin banana), Jobs, Reviews,
Sections (workers, engineers, medical aur equipment categories add/hide/manage), Settings, aur Log (admin ne kya kiya).

## Razorpay payment setup (recommended)

1. Create a Razorpay account and generate **Test Mode** API keys in the Razorpay Dashboard.
2. Install dependencies: `pip install -r requirements.txt`.
3. Set environment variables before starting Flask (never paste secrets into source code):
   - Windows PowerShell: `$env:RAZORPAY_KEY_ID="rzp_test_xxxxx"` and `$env:RAZORPAY_KEY_SECRET="your_test_secret"`
   - macOS/Linux: `export RAZORPAY_KEY_ID="rzp_test_xxxxx"` and `export RAZORPAY_KEY_SECRET="your_test_secret"`
4. Start the app with `python app.py`. When both variables are set, customers see the Razorpay payment button. Otherwise the legacy UPI/UTR method remains available.
5. In Razorpay Dashboard, enable **automatic capture** for orders and test successful, failed, cancelled, and duplicate-submit cases. The app only marks a booking paid after server-side signature verification and a captured-payment/amount/order check.
6. For reliable background confirmation, set `RAZORPAY_WEBHOOK_SECRET` and configure the Razorpay webhook URL as `https://YOUR-DOMAIN/webhooks/razorpay` for `payment.captured` and `order.paid` events. Keep the webhook secret separate from the API secret.
7. Use HTTPS and Live Mode keys only after end-to-end testing. Never commit `.env`, API secrets, or live credentials.

The customer payment is verified automatically; **worker payouts remain manual**, as requested. Doctor and equipment categories are service listings only; medical emergencies should use local emergency services, and equipment hire should confirm operator, transport, insurance and safety terms directly. Admin must actually transfer the worker amount (booking amount minus commission) and then record the payout reference in Admin → Payments. The website does not send bank transfers automatically.

## Legacy payment flow (UPI, commission)

1. Customer worker ko "काम बुक करें" se booking banata hai aur rakam tay karta hai.
2. Customer woh rakam **site ki UPI ID** par bhejta hai aur 12 ankon ka UTR number dalta hai.
3. Admin apna bank/UPI statement dekhkar "Payment received" dabata hai. Ab paisa "held" hai.
4. Kaam hone par customer "काम पूरा हो गया" dabata hai.
5. Admin worker ki UPI ID par (rakam minus commission) bhejta hai, aur payout ka UTR save karta hai.

Example: rakam ₹1000, commission 10% -> worker ko ₹900, site ke ₹100.

### Zaroori sachchai

- UPI mein yahan **paisa apne aap verify nahi hota**. Admin ko har payment ka statement khud dekhna padta hai.
  Jab bookings zyada hon, to Razorpay/Cashfree jaisa payment gateway lagana chahiye (auto verify + auto split).
- Dusron ka paisa apne account mein rakhna kuch jagah rules ke andar aa sakta hai.
  Asli paise se shuru karne se pehle kisi CA ya vakeel se pooch lo.

## Security (pehle se laga hai)

- Password hash hokar save hota hai; galat password 5 baar par 10 minute ka lock
- Har form mein CSRF token; photo ki asli type check (JPG/PNG/WEBP, max 2 MB)
- Phone number sirf logged-in logon ko dikhta hai; admin pages sirf admin ko
- Blocked user login nahi kar sakta aur uski profile chhup jaati hai

## Internet par daalne se pehle

- `python app.py` sirf testing ke liye hai. Live ke liye gunicorn/waitress + HTTPS use karo.
- `.secret_key` kisi ko mat do. `karigar.db` aur `static/uploads/` ka roz backup lo.
- Purana (pehla version ka) `karigar.db` ho to apne aap upgrade ho jaata hai.
