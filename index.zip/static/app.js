// Show the "Your work" box only for workers on the register page.
(function () {
  var box = document.getElementById("catbox");
  if (box) {
    var label = box.closest("label");
    var radios = document.querySelectorAll('input[name="role"]');
    var sync = function () {
      var picked = document.querySelector('input[name="role"]:checked');
      label.classList.toggle("hidden", !picked || picked.value !== "worker");
    };
    radios.forEach(function (r) { r.addEventListener("change", sync); });
    sync();
  }
  var end = document.getElementById("end");
  if (end) { end.scrollIntoView(); }
})();

// Ask "are you sure?" before risky buttons (they carry data-confirm).
document.addEventListener("submit", function (e) {
  var b = e.submitter;
  if (b && b.dataset && b.dataset.confirm && !window.confirm(b.dataset.confirm)) { e.preventDefault(); }
});


// Razorpay Checkout: create orders on the server and verify the signed response server-side.
(function () {
  var button = document.getElementById("razorpay-pay");
  if (!button) return;
  var message = document.getElementById("razorpay-message");
  function say(text) { if (message) message.textContent = text; }
  button.addEventListener("click", async function () {
    button.disabled = true; say("Opening secure checkout…");
    try {
      var response = await fetch(button.dataset.orderUrl, { method: "POST", headers: {
        "Content-Type": "application/json", "X-CSRF-Token": button.dataset.csrf
      }, body: "{}" });
      var order = await response.json();
      if (!response.ok) throw new Error(order.error || "Could not create payment order.");
      if (typeof window.Razorpay !== "function") {
        await new Promise(function (resolve, reject) {
          var script = document.createElement("script"); script.src = "https://checkout.razorpay.com/v1/checkout.js";
          script.onload = resolve; script.onerror = reject; document.head.appendChild(script);
        });
      }
      var checkout = new window.Razorpay({ key: order.key_id, order_id: order.order_id, amount: order.amount,
        currency: order.currency, name: order.name, description: order.description,
        handler: async function (result) {
          say("Verifying payment securely…");
          try {
            var verified = await fetch(button.dataset.verifyUrl, { method: "POST", headers: {
              "Content-Type": "application/json", "X-CSRF-Token": button.dataset.csrf
            }, body: JSON.stringify(result) });
            var outcome = await verified.json();
            if (!verified.ok || !outcome.ok) throw new Error(outcome.error || "Verification pending.");
            say("Payment verified. Refreshing booking…"); window.location.reload();
          } catch (err) { say(err.message + " Do not pay again; refresh this page or contact support."); button.disabled = false; }
        },
        modal: { ondismiss: function () { say("Checkout closed. If you completed payment, refresh before trying again."); button.disabled = false; } },
        theme: { color: "#17324d" }
      });
      checkout.on("payment.failed", function () { say("Payment failed. You can try again."); button.disabled = false; });
      checkout.open();
    } catch (err) { say(err.message || "Payment could not be started."); button.disabled = false; }
  });
})();
